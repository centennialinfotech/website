// cloudinaryConfig.js
const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: 'dvfmw4c9f',
  api_key: '683912699553392',
  api_secret: 'TN9NXfAS62gNkpYm63SCZ9iyxPM',
});

module.exports = cloudinary;
